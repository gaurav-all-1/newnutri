export const environment = {
  production: true,
  demo: 'demo1',
  SERVER_URL: 'https://d-themes.com/angular/molla/server'
};
